package com.hospital.ms_medicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMedicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
